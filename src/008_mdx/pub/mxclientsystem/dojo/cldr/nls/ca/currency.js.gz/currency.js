/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ca/currency",{HKD_displayName:"d\u00f2lar de Hong Kong",CHF_displayName:"franc su\u00eds",JPY_symbol:"JP\u00a5",CAD_displayName:"d\u00f2lar canadenc",HKD_symbol:"HK$",CNY_displayName:"iuan xin\u00e8s",USD_symbol:"$",AUD_displayName:"d\u00f2lar australi\u00e0",JPY_displayName:"ien japon\u00e8s",CAD_symbol:"CA$",USD_displayName:"d\u00f2lar dels Estats Units",EUR_symbol:"\u20ac",CNY_symbol:"\u00a5",GBP_displayName:"lliura esterlina brit\u00e0nica",GBP_symbol:"\u00a3",AUD_symbol:"AU$",
EUR_displayName:"euro"});
