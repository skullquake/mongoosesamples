/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/id/chinese",{"field-sat-relative+0":"Sabtu ini","field-sat-relative+1":"Sabtu berikutnya","field-dayperiod":"AM/PM","field-sun-relative+-1":"Minggu lalu","field-mon-relative+-1":"Senin lalu","field-minute":"Menit","field-day-relative+-1":"kemarin","field-weekday":"Hari dalam Seminggu","field-day-relative+-2":"kemarin lusa","months-standAlone-narrow":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-era":"Era","field-hour":"Jam","field-sun-relative+0":"Minggu ini","field-sun-relative+1":"Minggu berikutnya",
"months-standAlone-abbr":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-wed-relative+-1":"Rabu lalu","field-day-relative+0":"hari ini","field-day-relative+1":"besok","field-day-relative+2":"lusa","dateFormat-long":"U MMMM d","field-tue-relative+0":"Selasa ini","field-zone":"Zona Waktu","field-tue-relative+1":"Selasa berikutnya","field-week-relative+-1":"minggu lalu","dateFormat-medium":"U MMM d","field-year-relative+0":"tahun ini","field-year-relative+1":"tahun depan","field-sat-relative+-1":"Sabtu lalu",
"field-year-relative+-1":"tahun lalu","field-year":"Tahun","field-fri-relative+0":"Jumat ini","field-fri-relative+1":"Jumat berikutnya","months-standAlone-wide":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-week":"Minggu","field-week-relative+0":"minggu ini","field-week-relative+1":"Minggu berikutnya","months-format-abbr":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-month-relative+0":"bulan ini","field-month":"Bulan","field-month-relative+1":"Bulan berikutnya","field-fri-relative+-1":"Jumat lalu",
"field-second":"Detik","field-tue-relative+-1":"Selasa lalu","field-day":"Hari","months-format-narrow":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-mon-relative+0":"Senin ini","field-mon-relative+1":"Senin berikutnya","field-thu-relative+0":"Kamis ini","field-second-relative+0":"sekarang","dateFormat-short":"y-M-d","field-thu-relative+1":"Kamis berikutnya","dateFormat-full":"EEEE, U MMMM dd","months-format-wide":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"field-wed-relative+0":"Rabu ini","field-wed-relative+1":"Rabu berikutnya",
"field-month-relative+-1":"bulan lalu","field-thu-relative+-1":"Kamis lalu"});
