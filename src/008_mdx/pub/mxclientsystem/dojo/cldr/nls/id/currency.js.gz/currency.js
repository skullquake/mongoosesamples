/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/id/currency",{HKD_displayName:"Dolar Hong Kong",CHF_displayName:"Franc Swiss",JPY_symbol:"JP\u00a5",CAD_displayName:"Dolar Kanada",HKD_symbol:"HK$",CNY_displayName:"Yuan China",USD_symbol:"US$",AUD_displayName:"Dolar Australia",JPY_displayName:"Yen Jepang",CAD_symbol:"CA$",USD_displayName:"Dolar Amerika Serikat",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"Pound Sterling Inggris",GBP_symbol:"\u00a3",AUD_symbol:"AU$",EUR_displayName:"Euro"});
