/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sv/currency",{HKD_displayName:"Hongkong-dollar",CHF_displayName:"schweizisk franc",JPY_symbol:"JP\u00a5",CAD_displayName:"kanadensisk dollar",HKD_symbol:"HK$",CNY_displayName:"kinesisk yuan renminbi",USD_symbol:"US$",AUD_displayName:"australisk dollar",JPY_displayName:"japansk yen",CAD_symbol:"CAN$",USD_displayName:"US-dollar",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"brittiskt pund sterling",GBP_symbol:"GB\u00a3",AUD_symbol:"AU$",EUR_displayName:"euro"});
