/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/bs/generic",{"dateFormatItem-yyyyMMMEd":"E, dd. MMM y. G","field-dayperiod":"pre podne/ popodne","field-minute":"minut","dateFormatItem-MMMEd":"E, dd. MMM","field-day-relative+-1":"ju\u010de","dateFormatItem-hms":"hh:mm:ss a","field-day-relative+-2":"prekju\u010de","field-weekday":"dan u nedelji","dateFormatItem-MMM":"LLL","field-era":"era","dateFormatItem-Gy":"y. G","field-hour":"\u010das","dateFormatItem-y":"y. G","dateFormatItem-yyyy":"y. G","dateFormatItem-Ed":"E, dd.","field-day-relative+0":"danas",
"field-day-relative+1":"sutra","field-day-relative+2":"prekosutra","dateFormatItem-GyMMMd":"dd. MMM y. G","dateFormat-long":"dd. MMMM y. G","field-zone":"zona","dateFormatItem-Hm":"HH:mm","dateFormat-medium":"dd.MM.y. G","dateFormatItem-Hms":"HH:mm:ss","dateFormatItem-ms":"mm:ss","field-year":"godina","dateFormatItem-yyyyQQQQ":"G y QQQQ","field-week":"nedelja","dateFormatItem-yyyyMd":"dd.MM.y. G","dateFormatItem-yyyyMMMd":"dd. MMM y. G","dateFormatItem-yyyyMEd":"E, dd.MM.y. G","dateFormatItem-MMMd":"dd. MMM",
"field-month":"mesec","dateFormatItem-M":"L","field-second":"sekund","dateFormatItem-GyMMMEd":"E, dd. MMM y. G","dateFormatItem-GyMMM":"MMM y. G","field-day":"dan","dateFormatItem-yyyyQQQ":"G y QQQ","dateFormatItem-MEd":"E, dd.MM.","dateFormatItem-hm":"hh:mm a","dateFormat-short":"dd.MM.y. GGGGG","dateFormatItem-yyyyM":"MM.y. G","dateFormat-full":"EEEE, dd. MMMM y. G","dateFormatItem-Md":"dd.MM.","dateFormatItem-yyyyMMM":"MMM y. G","dateFormatItem-d":"d"});
