/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/pl/currency",{HKD_displayName:"dolar hongko\u0144ski",CHF_displayName:"frank szwajcarski",JPY_symbol:"JPY",CAD_displayName:"dolar kanadyjski",HKD_symbol:"HKD",CNY_displayName:"juan chi\u0144ski",USD_symbol:"USD",AUD_displayName:"dolar australijski",JPY_displayName:"jen japo\u0144ski",CAD_symbol:"CAD",USD_displayName:"dolar ameryka\u0144ski",CNY_symbol:"CNY",GBP_displayName:"funt szterling",GBP_symbol:"GBP",AUD_symbol:"AUD",EUR_displayName:"euro"});
