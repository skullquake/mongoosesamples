/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/es/currency",{HKD_displayName:"d\u00f3lar de Hong Kong",CHF_displayName:"franco suizo",JPY_symbol:"JPY",CAD_displayName:"d\u00f3lar canadiense",HKD_symbol:"HKD",CNY_displayName:"yuan chino",USD_symbol:"$",AUD_displayName:"d\u00f3lar australiano",JPY_displayName:"yen japon\u00e9s",CAD_symbol:"CA$",USD_displayName:"d\u00f3lar estadounidense",CNY_symbol:"CNY",GBP_displayName:"libra esterlina brit\u00e1nica",GBP_symbol:"GBP",AUD_symbol:"AU$",EUR_displayName:"euro"});
