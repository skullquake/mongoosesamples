/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/es/roc",{"field-sat-relative+0":"este s\u00e1bado","field-sat-relative+1":"el pr\u00f3ximo s\u00e1bado","field-dayperiod":"periodo del d\u00eda","field-sun-relative+-1":"el domingo pasado","field-mon-relative+-1":"el lunes pasado","field-minute":"minuto","field-day-relative+-1":"ayer","field-weekday":"d\u00eda de la semana","field-day-relative+-2":"antes de ayer","field-era":"era","field-hour":"hora","field-sun-relative+0":"este domingo","field-sun-relative+1":"el pr\u00f3ximo domingo",
"field-wed-relative+-1":"el mi\u00e9rcoles pasado","field-day-relative+0":"hoy","field-day-relative+1":"ma\u00f1ana",eraAbbr:["antes de R.O.C."],"field-day-relative+2":"pasado ma\u00f1ana","field-tue-relative+0":"este martes","field-zone":"zona horaria","field-tue-relative+1":"el pr\u00f3ximo martes","field-week-relative+-1":"la semana pasada","field-year-relative+0":"este a\u00f1o","field-year-relative+1":"el pr\u00f3ximo a\u00f1o","field-sat-relative+-1":"el s\u00e1bado pasado","field-year-relative+-1":"el a\u00f1o pasado",
"field-year":"a\u00f1o","field-fri-relative+0":"este viernes","field-fri-relative+1":"el pr\u00f3ximo viernes","field-week":"semana","field-week-relative+0":"esta semana","field-week-relative+1":"la pr\u00f3xima semana","field-month-relative+0":"este mes","field-month":"mes","field-month-relative+1":"el pr\u00f3ximo mes","field-fri-relative+-1":"el viernes pasado","field-second":"segundo","field-tue-relative+-1":"el martes pasado","field-day":"d\u00eda","field-mon-relative+0":"este lunes","field-mon-relative+1":"el pr\u00f3ximo lunes",
"field-thu-relative+0":"este jueves","field-second-relative+0":"ahora","field-thu-relative+1":"el pr\u00f3ximo jueves","field-wed-relative+0":"este mi\u00e9rcoles","field-wed-relative+1":"el pr\u00f3ximo mi\u00e9rcoles","field-month-relative+-1":"el mes pasado","field-thu-relative+-1":"el jueves pasado"});
