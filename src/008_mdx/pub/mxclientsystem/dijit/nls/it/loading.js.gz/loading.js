//>>built
define("dijit/nls/it/loading",{loadingState:"Caricamento in corso...",errorState:"Si \u00e8 verificato un errore"});
