//>>built
define("dijit/nls/zh-tw/loading",{loadingState:"\u8f09\u5165\u4e2d...",errorState:"\u62b1\u6b49\uff0c\u767c\u751f\u932f\u8aa4"});
