//>>built
define("dijit/nls/sl/common",{buttonOk:"V redu",buttonCancel:"Prekli\u010di",buttonSave:"Shrani",itemClose:"Zapri"});
