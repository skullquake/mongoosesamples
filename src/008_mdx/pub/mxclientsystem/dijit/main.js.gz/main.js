//>>built
define("dijit/main",["dojo/_base/kernel"],function(a){return a.dijit});
