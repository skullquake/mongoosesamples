//>>built
define("dijit/form/nls/es/ComboBox",{previousMessage:"Opciones anteriores",nextMessage:"M\u00e1s opciones"});
