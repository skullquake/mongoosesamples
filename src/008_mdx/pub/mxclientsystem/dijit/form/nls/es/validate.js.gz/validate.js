//>>built
define("dijit/form/nls/es/validate",{invalidMessage:"El valor especificado no es v\u00e1lido.",missingMessage:"Este valor es necesario.",rangeMessage:"Este valor est\u00e1 fuera del intervalo."});
