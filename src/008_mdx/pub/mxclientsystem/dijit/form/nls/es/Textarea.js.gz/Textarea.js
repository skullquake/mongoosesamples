//>>built
define("dijit/form/nls/es/Textarea",{iframeEditTitle:"\u00e1rea de edici\u00f3n",iframeFocusTitle:"marco del \u00e1rea de edici\u00f3n"});
