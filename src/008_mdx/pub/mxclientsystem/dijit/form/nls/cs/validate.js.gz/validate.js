//>>built
define("dijit/form/nls/cs/validate",{invalidMessage:"Zadan\u00e1 hodnota nen\u00ed platn\u00e1.",missingMessage:"Tato hodnota je vy\u017eadov\u00e1na.",rangeMessage:"Tato hodnota je mimo rozsah."});
