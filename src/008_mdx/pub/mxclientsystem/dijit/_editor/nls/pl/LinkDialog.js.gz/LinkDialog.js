//>>built
define("dijit/_editor/nls/pl/LinkDialog",{createLinkTitle:"W\u0142a\u015bciwo\u015bci odsy\u0142acza",insertImageTitle:"W\u0142a\u015bciwo\u015bci obrazu",url:"Adres URL:",text:"Opis:",target:"Docelowe:",set:"Ustaw",currentWindow:"Bie\u017c\u0105ce okno",parentWindow:"Okno macierzyste",topWindow:"Okno najwy\u017cszego poziomu",newWindow:"Nowe okno"});
