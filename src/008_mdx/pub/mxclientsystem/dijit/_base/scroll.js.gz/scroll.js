//>>built
define("dijit/_base/scroll",["dojo/window","../main"],function(b,a){a.scrollIntoView=function(a,c){b.scrollIntoView(a,c)}});
